title: Give yourself a hand
date: '2019-09-14 07:51:50'
updated: '2019-09-14 08:31:23'
tags: [鸡汤]
permalink: /articles/2019/09/14/1568418710550.html
---
![7e5f8213gy1fymv0ks5x3j20u010pqai.jpg](https://img.hacpai.com/file/2019/09/7e5f8213gy1fymv0ks5x3j20u010pqai-5ac4d332.jpg)

nerver give up,keep moving!
